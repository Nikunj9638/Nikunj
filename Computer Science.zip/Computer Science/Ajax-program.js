$(document).ready(function(){
  
  $('#fetchhtml').on('click',function(){ 
  $('#one').load('http://localhost/Sweater1.jpg);
  });

});